import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'quiz1-corte3',
  webDir: 'dist'
};

export default config;
